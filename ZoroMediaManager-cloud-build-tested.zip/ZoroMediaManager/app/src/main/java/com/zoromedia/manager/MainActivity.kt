package com.zoromedia.manager

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.InputStream

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 11, 20)
    private val panel = Color.rgb(20, 23, 38)
    private val accent = Color.rgb(217, 70, 239)
    private val muted = Color.rgb(165, 172, 195)
    private val accounts = mutableListOf<String>()
    private val statuses = mutableMapOf<String, String>()
    private lateinit var accountBox: LinearLayout
    private lateinit var dpPreview: ImageView
    private lateinit var postPreview: ImageView
    private lateinit var statusText: TextView
    private lateinit var professionalSwitch: Switch
    private var dpUri: Uri? = null
    private var postUris = mutableListOf<Uri>()
    private var choosingDp = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(18), dp(18), dp(20))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(label("ZORO MEDIA MANAGER", 22, Color.WHITE, true))
        content.addView(label("Shared media • account-by-account workflow", 13, muted, false).apply {
            setPadding(0, dp(5), 0, dp(18))
        })

        content.addView(sectionTitle("SHARED PROFILE PICTURE"))
        dpPreview = imagePreview()
        content.addView(dpPreview, LinearLayout.LayoutParams(-1, dp(190)))
        content.addView(button("Choose DP image") { chooseImage(true) })

        content.addView(sectionTitle("SHARED POSTS"))
        postPreview = imagePreview()
        content.addView(postPreview, LinearLayout.LayoutParams(-1, dp(190)))
        content.addView(label("Selected post images: 1 default image", 13, muted, false).also { statusText = it })
        content.addView(button("Choose multiple post images") { chooseImage(false) })

        content.addView(sectionTitle("ACCOUNT LIST"))
        content.addView(label("Add account usernames/labels only. Sign in inside Honista yourself; this app does not collect or store passwords or 2FA secrets.", 13, muted, false).apply {
            setPadding(0, 0, 0, dp(10))
        })
        val addRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val accountInput = EditText(this).apply {
            hint = "Username or account label"
            setHintTextColor(muted)
            setTextColor(Color.WHITE)
            textSize = 14f
            singleLine = true
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundColor(panel)
        }
        addRow.addView(accountInput, LinearLayout.LayoutParams(0, dp(48), 1f))
        addRow.addView(button("Add") {
            val name = accountInput.text.toString().trim()
            if (name.isBlank()) toast("Enter an account username or label")
            else if (accounts.any { it.equals(name, true) }) toast("Account already added")
            else {
                accounts.add(name); statuses[name] = "Ready"
                accountInput.setText(""); renderAccounts()
            }
        }, LinearLayout.LayoutParams(dp(78), dp(48)).apply { leftMargin = dp(8) })
        content.addView(addRow)
        accountBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(2))
        }
        content.addView(accountBox)
        renderAccounts()

        content.addView(sectionTitle("OPTIONS"))
        professionalSwitch = Switch(this).apply {
            text = "Make account professional (manual step)"
            setTextColor(Color.WHITE)
            textSize = 14f
            isChecked = false
        }
        content.addView(professionalSwitch)
        content.addView(label("ON adds a reminder to each account checklist. You must confirm account changes yourself in Honista.", 12, muted, false).apply {
            setPadding(0, dp(4), 0, dp(10))
        })

        content.addView(button("START ACCOUNT WORKFLOW") { startWorkflow() })
        content.addView(label("This app prepares shared media and opens Honista where available. Login, 2FA, profile changes, and publishing remain user-confirmed.", 12, muted, false).apply {
            setPadding(0, dp(12), 0, dp(8))
        })

        setContentView(root)
        loadDefaultImage(dpPreview)
        loadDefaultImage(postPreview)
    }

    private fun startWorkflow() {
        if (accounts.isEmpty()) { toast("Add at least one account first"); return }
        val tasks = accounts.mapIndexed { i, name ->
            "${i + 1}. $name\n   • Sign in/select this account in Honista\n   • Set shared DP\n   • Publish ${postUris.size.coerceAtLeast(1)} shared post image(s)" +
                if (professionalSwitch.isChecked) "\n   • Optional: switch to professional account" else ""
        }
        val msg = tasks.joinToString("\n\n")
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Account workflow")
            .setMessage(msg)
            .setNegativeButton("Close", null)
            .setPositiveButton("Open Honista") { _, _ -> openHonista() }
            .create()
        dialog.show()
    }

    private fun openHonista() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
        val app = apps.firstOrNull {
            val label = pm.getApplicationLabel(it).toString()
            label.contains("Honista", true)
        }
        if (app != null) {
            val launch = pm.getLaunchIntentForPackage(app.packageName)
            if (launch != null) { startActivity(launch); return }
        }
        toast("Honista was not found. Open it manually, then continue the checklist.")
    }

    private fun renderAccounts() {
        if (!::accountBox.isInitialized) return
        accountBox.removeAllViews()
        if (accounts.isEmpty()) {
            accountBox.addView(label("No accounts added yet.", 13, muted, false).apply {
                setPadding(0, dp(8), 0, dp(8))
            })
        }
        accounts.forEachIndexed { index, name ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(8), dp(8), dp(8))
                setBackgroundColor(panel)
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label("${index + 1}. $name", 14, Color.WHITE, true))
            info.addView(label(statuses[name] ?: "Ready", 12, muted, false))
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val remove = TextView(this).apply {
                text = "Remove"; textSize = 12f; setTextColor(Color.rgb(255, 130, 150))
                setPadding(dp(8), dp(10), dp(8), dp(10))
                setOnClickListener { accounts.remove(name); statuses.remove(name); renderAccounts() }
            }
            row.addView(remove)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(6)
            accountBox.addView(row, lp)
        }
    }

    private fun chooseImage(dpMode: Boolean) {
        choosingDp = dpMode
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            if (!dpMode) putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, if (dpMode) 101 else 102)
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data == null) return
        if (requestCode == 101) {
            dpUri = data.data
            dpUri?.let { showUri(dpPreview, it) }
        } else if (requestCode == 102) {
            postUris.clear()
            data.clipData?.let { clip ->
                for (i in 0 until clip.itemCount) postUris.add(clip.getItemAt(i).uri)
            } ?: data.data?.let { postUris.add(it) }
            if (postUris.isNotEmpty()) {
                showUri(postPreview, postUris.first())
                statusText.text = "Selected post images: ${postUris.size}"
            } else statusText.text = "Selected post images: 1 default image"
        }
    }

    private fun showUri(view: ImageView, uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { stream -> view.setImageBitmap(BitmapFactory.decodeStream(stream)) }
        } catch (_: Exception) { toast("Could not load selected image") }
    }

    private fun loadDefaultImage(view: ImageView) {
        try {
            assets.open("zoro.jpg").use { stream ->
                view.setImageBitmap(BitmapFactory.decodeStream(stream))
            }
        } catch (_: Exception) {}
    }

    private fun imagePreview() = ImageView(this).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        setBackgroundColor(panel)
        setPadding(dp(2), dp(2), dp(2), dp(2))
    }

    private fun sectionTitle(text: String): TextView =
        label(text, 12, accent, true).apply { setPadding(0, dp(18), 0, dp(8)) }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 13f; isAllCaps = false
        setTextColor(Color.WHITE); setBackgroundColor(accent)
        setOnClickListener { action() }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
